class QuestionObj {
  String narration;
  String option_a;
  String option_b;
  String option_c;
  String option_d;
  String answer;
  String photo;

  QuestionObj(this.narration, this.option_a, this.option_b, this.option_c,
      this.option_d, this.answer, this.photo);
}
